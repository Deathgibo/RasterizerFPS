I *think* the alpha map is used for the specular levels.
The color change maps are used for setting the armor color and applying the detail map.
Metal_Dirty should be tiled 9x9 as the detail map. 
Also UVW's on the Multiplayer Emblem parts are screwed up so you'll need to fix those yourself if you want to use them.