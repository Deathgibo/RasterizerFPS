This model was ripped by Shadowth117 with either the Entity model exporter or ADI model extraction library for Halo 2 and Gravemind 1.5 for Halo 2 Vista. No credit needed. 

Note: Some material components will have to be applied manually since neither Collada nor .mtl format supports them. This includes, but is not limited to detail maps, and reflection maps among many other things.

Some of the textures were ripped from Halo 2 Vista with Gravemind 1.5 rather than Halo2 because Entity didn't export them correctly or to get the high-res version of a particular texture. Things with high-res textures unfortunately only seem to be UI elements while everything else is pretty much unchanged. 

