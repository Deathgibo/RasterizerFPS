Map: Cliffhanger
Author: Molkien
email: creepy2515@hotmail.com
web: http://molkien.halocity.org

Thank you for downloading Cliffhanger for Halo Custom Edition. This is the first of many maps to come, so please let me know what you think of it, and feel free to email me feedback / questions.

Aside from the level itself, I also created an original skybox model, and a custom tree (resembling the tree_leafycover_doublewide) with a collision model. I will be releasing these within a week or two of this maps release, along with custom textures, and possibly even the base structure as well.

Hope you enjoy!

-Molkien