This model was ripped by Shadowth117 using TheGhost's Halo CE model importer and FireScythe's BSP Tag Converter v2.5. No credit needed. TMR only!

Notes: You may have to apply appropriate detail maps to your materials to get certain materials on the map to look like they do ingame.